package androidx.versionedparcelable;

/* renamed from: androidx.versionedparcelable.R */
public final class C0268R {
}
